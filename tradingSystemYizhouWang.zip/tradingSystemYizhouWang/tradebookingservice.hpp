/**
 * tradebookingservice.hpp
 * Defines the data types and Service for trade booking.
 *
 * @author Breman Thuraisingham
 */
#ifndef TRADE_BOOKING_SERVICE_HPP
#define TRADE_BOOKING_SERVICE_HPP

#include <string>
#include <vector>
#include "soa.hpp"
#include "executionservice.hpp"

// Trade sides
enum Side { BUY, SELL };

/**
 * Trade object with a price, side, and quantity on a particular book.
 * Type T is the product type.
 */
template<typename T>
class Trade
{

public:
    
    Trade();

  // ctor for a trade
  Trade(const T &_product, string _tradeId, double _price, string _book, long _quantity, Side _side);

  // Get the product
  const T& GetProduct() const;

  // Get the trade ID
  const string& GetTradeId() const;

  // Get the mid price
  double GetPrice() const;

  // Get the book
  const string& GetBook() const;

  // Get the quantity
  long GetQuantity() const;

  // Get the side
  Side GetSide() const;

private:
  T product;
  string tradeId;
  double price;
  string book;
  long quantity;
  Side side;

};

/**
 * Trade Booking Service to book trades to a particular book.
 * Keyed on trade id.
 * Type T is the product type.
 */
template<typename T>
class TradeBookingConnector;

template<typename T>
class TradeBookingToExecutionListener;

template<typename T>
class TradeBookingService : public Service<string,Trade <T> >
{

public:
    TradeBookingService();

    Trade<T>& GetData(string key);

    void OnMessage(Trade<T>& data);

    void AddListener(ServiceListener<Trade<T>>* listener);

    const vector<ServiceListener<Trade<T>>*>& GetListeners() const;

    TradeBookingConnector<T>* GetConnector();

    TradeBookingToExecutionListener<T>* GetListener();
    
    // Book the trade
    void BookTrade(Trade<T> &trade);
    
private:

    map<string, Trade<T>> trades;
    vector<ServiceListener<Trade<T>>*> listeners;
    TradeBookingConnector<T>* connector;
    TradeBookingToExecutionListener<T>* listener;
};

template<typename T>
Trade<T>::Trade(){}

template<typename T>
Trade<T>::Trade(const T &_product, string _tradeId, double _price, string _book, long _quantity, Side _side) :
  product(_product)
{
  tradeId = _tradeId;
  price = _price;
  book = _book;
  quantity = _quantity;
  side = _side;
}

template<typename T>
const T& Trade<T>::GetProduct() const
{
  return product;
}

template<typename T>
const string& Trade<T>::GetTradeId() const
{
  return tradeId;
}

template<typename T>
double Trade<T>::GetPrice() const
{
  return price;
}

template<typename T>
const string& Trade<T>::GetBook() const
{
  return book;
}

template<typename T>
long Trade<T>::GetQuantity() const
{
  return quantity;
}

template<typename T>
Side Trade<T>::GetSide() const
{
  return side;
}


template<typename T>
TradeBookingService<T>::TradeBookingService(): trades(),listeners(),connector(new TradeBookingConnector<T>(this)),listener(new TradeBookingToExecutionListener<T>(this))
{
}

template<typename T>
Trade<T>& TradeBookingService<T>::GetData(string key)
{
    return trades[key];
}

template<typename T>
void TradeBookingService<T>::OnMessage(Trade<T>& data)
{
    trades[data.GetTradeId()] = data;

    for (auto& l : listeners) l->ProcessAdd(data);
}

template<typename T>
void TradeBookingService<T>::AddListener(ServiceListener<Trade<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<Trade<T>>*>& TradeBookingService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
TradeBookingConnector<T>* TradeBookingService<T>::GetConnector()
{
    return connector;
}

template<typename T>
TradeBookingToExecutionListener<T>* TradeBookingService<T>::GetListener()
{
    return listener;
}

template<typename T>
void TradeBookingService<T>::BookTrade(Trade<T>& trade)
{
    for (auto& l : listeners) l->ProcessAdd(trade);
}

template<typename T>
class TradeBookingConnector : public Connector<Trade<T>>
{

private:

    TradeBookingService<T>* service;

public:

    TradeBookingConnector(TradeBookingService<T>* _service);

    void Publish(Trade<T>& _data);

    void Subscribe(ifstream& _data);

};

template<typename T>
TradeBookingConnector<T>::TradeBookingConnector(TradeBookingService<T>* service): service(service)
{
}

template<typename T>
void TradeBookingConnector<T>::Publish(Trade<T>& _data) {}

template<typename T>
void TradeBookingConnector<T>::Subscribe(ifstream& data)
{
    string _line;
    while (getline(data, _line))
    {
        stringstream _lineStream(_line);
        string _cell;
        vector<string> _cells;
        while (getline(_lineStream, _cell, ','))
        {
            _cells.push_back(_cell);
        }

        string _productId = _cells[0];
        string _tradeId = _cells[1];
        double _price = StringPriceToNum(_cells[2]);
        string _book = _cells[3];
        long _quantity = stol(_cells[4]);
        Side _side;
        if (_cells[5] == "BUY") _side = BUY;
        else if (_cells[5] == "SELL") _side = SELL;
        T _product = GetTreasuryFromCUSIP(_productId);
        Trade<T> _trade(_product, _tradeId, _price, _book, _quantity, _side);
        service->OnMessage(_trade);
    }
}

template<typename T>
class TradeBookingToExecutionListener : public ServiceListener<ExecutionOrder<T>>
{

private:

    TradeBookingService<T>* service;
    long trade_count;

public:

    TradeBookingToExecutionListener(TradeBookingService<T>* service);

    void ProcessAdd(ExecutionOrder<T>& data);

    void ProcessRemove(ExecutionOrder<T>& data);

    void ProcessUpdate(ExecutionOrder<T>& data);

};

template<typename T>
TradeBookingToExecutionListener<T>::TradeBookingToExecutionListener(TradeBookingService<T>* service):service(service),trade_count(0)
{
}


template<typename T>
void TradeBookingToExecutionListener<T>::ProcessAdd(ExecutionOrder<T>& order)
{
    
    T curr_product = order.GetProduct();

    Side side;
    if (order.GetPricingSide() == BID) side = SELL;
    else side = BUY;
    
    trade_count++;
    string book;
    if (trade_count % 3 == 0) book = "TRSY1";
    else if (trade_count % 3 == 1) book = "TRSY2";
    else book = "TRSY3";

    Trade<T> trade(curr_product, order.GetOrderId(), order.GetPrice(), book, order.GetVisibleQuantity() + order.GetHiddenQuantity(), side);
    service->OnMessage(trade);
    service->BookTrade(trade);
}

template<typename T>
void TradeBookingToExecutionListener<T>::ProcessRemove(ExecutionOrder<T>& data) {}

template<typename T>
void TradeBookingToExecutionListener<T>::ProcessUpdate(ExecutionOrder<T>& data) {}

#endif
