/**
 * positionservice.hpp
 * Defines the data types and Service for positions.
 *
 * @author Breman Thuraisingham
 */
#ifndef POSITION_SERVICE_HPP
#define POSITION_SERVICE_HPP

#include <string>
#include <map>
#include "soa.hpp"
#include "tradebookingservice.hpp"

using namespace std;

/**
 * Position class in a particular book.
 * Type T is the product type.
 */
template<typename T>
class Position
{

public:
    
    Position();

  // ctor for a position
    Position(const T &_product);

  // Get the product
    const T& GetProduct() const;

  // Get the position quantity
    long GetPositionByBook(string &book);

  // Get the aggregate position
    long GetAggregatePosition();
    
    void ChangePositionByBook(string& book, long quant);
    
    vector<string> OutPut() const;

private:
  T product;
  map<string,long> positions;

};

template<typename T>
class PositionToTradeBookingListener;
/**
 * Position Service to manage positions across multiple books and secruties.
 * Keyed on product identifier.
 * Type T is the product type.
 */
template<typename T>
class PositionService : public Service<string,Position <T> >
{

public:

    PositionService();
    
    Position<T>& GetData(string key);

    void OnMessage(Position<T>& data);

    void AddListener(ServiceListener<Position<T>>* listener);

    const vector<ServiceListener<Position<T>>*>& GetListeners() const;

    PositionToTradeBookingListener<T>* GetListener();
    
    // Add a trade to the service
    virtual void AddTrade(const Trade<T> &trade);
    
private:

    map<string, Position<T>> positions;
    vector<ServiceListener<Position<T>>*> listeners;
    PositionToTradeBookingListener<T>* listener;

};

template<typename T>
Position<T>::Position(){}

template<typename T>
Position<T>::Position(const T &_product) :
  product(_product)
{
}

template<typename T>
const T& Position<T>::GetProduct() const
{
  return product;
}

template<typename T>
long Position<T>::GetPositionByBook(string &book)
{
  return positions[book];
}

template<typename T>
long Position<T>::GetAggregatePosition()
{
    long ans = 0;
    for(auto& p: positions ) ans += p.second;
    return ans;
}

template<typename T>
void Position<T>::ChangePositionByBook(string& book, long quant)
{
    positions[book] += quant;
}

template<typename T>
vector<string> Position<T>::OutPut() const
{
    string ticker = product.GetProductId();
    cout<<ticker<<endl;
    vector<string> _positions;
    for (auto& p : positions)
    {
        string _book = p.first;
        string _position = to_string(p.second);
        _positions.push_back(_book);
        _positions.push_back(_position);
    }

    vector<string> _strings;
    _strings.push_back(ticker);
    _strings.insert(_strings.end(), _positions.begin(), _positions.end());
    return _strings;
}


template<typename T>
PositionService<T>::PositionService(): positions(), listeners(), listener(new PositionToTradeBookingListener<T>(this))
{
}

template<typename T>
Position<T>& PositionService<T>::GetData(string key)
{
    return positions[key];
}

template<typename T>
void PositionService<T>::OnMessage(Position<T>& data)
{
    positions[data.GetProduct().GetProductId()] = data;
}

template<typename T>
void PositionService<T>::AddListener(ServiceListener<Position<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
PositionToTradeBookingListener<T>* PositionService<T>::GetListener()
{
    return listener;
}

template<typename T>
const vector<ServiceListener<Position<T>>*>& PositionService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
void PositionService<T>::AddTrade(const Trade<T>& curr_trade)
{
    string product_id = curr_trade.GetProduct().GetProductId();
    string book = curr_trade.GetBook();
    long quantity = curr_trade.GetQuantity();
    Side side = curr_trade.GetSide();

    Position<T>& position_of_prod = positions[product_id];
    if(side==BUY) position_of_prod.ChangePositionByBook(book, quantity);
    else position_of_prod.ChangePositionByBook(book,-quantity);

    for (auto& l : listeners) l->ProcessAdd(position_of_prod);
}


template<typename T>
class PositionToTradeBookingListener : public ServiceListener<Trade<T>>
{

private:

    PositionService<T>* service;

public:

    PositionToTradeBookingListener(PositionService<T>* _service);

    void ProcessAdd(Trade<T>& data);

    void ProcessRemove(Trade<T>& data);

    void ProcessUpdate(Trade<T>& data);

};

template<typename T>
PositionToTradeBookingListener<T>::PositionToTradeBookingListener(PositionService<T>* service): service(service)
{
}

template<typename T>
void PositionToTradeBookingListener<T>::ProcessAdd(Trade<T>& data)
{
    service->AddTrade(data);
}

template<typename T>
void PositionToTradeBookingListener<T>::ProcessRemove(Trade<T>& _data) {}

template<typename T>
void PositionToTradeBookingListener<T>::ProcessUpdate(Trade<T>& _data) {}

#endif
