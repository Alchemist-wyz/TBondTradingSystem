#ifndef ALGO_EXECUTION_SERVICE_HPP
#define ALGO_EXECUTION_SERVICE_HPP

#include <string>
#include "soa.hpp"
#include "marketdataservice.hpp"
#include "executionservice.hpp"

enum OrderType { FOK, IOC, MARKET, LIMIT, STOP };
enum Market { BROKERTEC, ESPEED, CME };


template<typename T>
class ExecutionOrder;

template<typename T>
class AlgoExecution
{

public:
    
    AlgoExecution();

	AlgoExecution(const T& _product, PricingSide _side, string _orderId, OrderType _orderType, double _price, long _visibleQuantity, long _hiddenQuantity, string _parentOrderId, bool _isChildOrder);

	// Get order
	ExecutionOrder<T>* GetExecutionOrder() const;

private:
	ExecutionOrder<T>* executionOrder;

};

template<typename T>
AlgoExecution<T>::AlgoExecution(){}

template<typename T>
AlgoExecution<T>::AlgoExecution(const T& product, PricingSide side, string orderId, OrderType orderType, double price, long visibleQuantity, long hiddenQuantity, string parentOrderId, bool isChildOrder): executionOrder(new ExecutionOrder (product, side, orderId, orderType, price, visibleQuantity, hiddenQuantity, parentOrderId, isChildOrder))
{
}

template<typename T>
ExecutionOrder<T>* AlgoExecution<T>::GetExecutionOrder() const
{
	return executionOrder;
}

template<typename T>
class AlgoExecutionToMarketDataListener;


template<typename T>
class AlgoExecutionService : public Service<string, AlgoExecution<T>>
{
public:

    AlgoExecutionService();

    AlgoExecution<T>& GetData(string key);

    void OnMessage(AlgoExecution<T>& data);

    void AddListener(ServiceListener<AlgoExecution<T>>* listener);

    const vector<ServiceListener<AlgoExecution<T>>*>& GetListeners() const;

    AlgoExecutionToMarketDataListener<T>* GetListener();

    void AlgoExecuteOrder(OrderBook<T>& orderBook);
    
private:

	map<string, AlgoExecution<T>> algo_exe;
	vector<ServiceListener<AlgoExecution<T>>*> listeners;
	AlgoExecutionToMarketDataListener<T>* listener;
	double min_spread;
	long trade_count;

};

template<typename T>
AlgoExecutionService<T>::AlgoExecutionService():algo_exe(),listeners(),listener(new AlgoExecutionToMarketDataListener<T>(this)),min_spread(1/128.),trade_count(0)
{
}

template<typename T>
AlgoExecution<T>& AlgoExecutionService<T>::GetData(string key)
{
	return algo_exe[key];
}

template<typename T>
void AlgoExecutionService<T>::OnMessage(AlgoExecution<T>& data)
{
	algo_exe[data.GetExecutionOrder()->GetProduct().GetProductId()] = data;
}

template<typename T>
void AlgoExecutionService<T>::AddListener(ServiceListener<AlgoExecution<T>>* listener)
{
	listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<AlgoExecution<T>>*>& AlgoExecutionService<T>::GetListeners() const
{
	return listeners;
}

template<typename T>
AlgoExecutionToMarketDataListener<T>* AlgoExecutionService<T>::GetListener()
{
	return listener;
}

template<typename T>
void AlgoExecutionService<T>::AlgoExecuteOrder(OrderBook<T>& orderBook)
{
	T prod = orderBook.GetProduct();
	PricingSide side;
	double price;
	long quant;

	BidOffer best_bid_offer = orderBook.GetBest();
	Order best_bid = best_bid_offer.GetBidOrder();
	Order best_offer = best_bid_offer.GetOfferOrder();

	if (best_offer.GetPrice() - best_bid.GetPrice() <= min_spread)
	{
		if (trade_count % 2 == 0)
        {
            price = best_bid.GetPrice();
            quant = best_bid.GetQuantity();
            side = BID;
        }
        else{
			price = best_offer.GetPrice();
			quant = best_offer.GetQuantity();
			side = OFFER;
		}
		
		AlgoExecution<T> algo_execution(prod, side, GetRandomID(), MARKET, price, quant, 0, "", false);
		algo_exe[prod.GetProductId()] = algo_execution;

		for (auto& l : listeners) l->ProcessAdd(algo_execution);
        
        trade_count++;
	}
}


template<typename T>
class AlgoExecutionToMarketDataListener : public ServiceListener<OrderBook<T>>
{

public:

	AlgoExecutionToMarketDataListener(AlgoExecutionService<T>* service);

	void ProcessAdd(OrderBook<T>& _data);

	void ProcessRemove(OrderBook<T>& _data);

	void ProcessUpdate(OrderBook<T>& _data);

    
private:

    AlgoExecutionService<T>* service;
};

template<typename T>
AlgoExecutionToMarketDataListener<T>::AlgoExecutionToMarketDataListener(AlgoExecutionService<T>* service): service(service)
{
}


template<typename T>
void AlgoExecutionToMarketDataListener<T>::ProcessAdd(OrderBook<T>& data)
{
	service->AlgoExecuteOrder(data);
}

template<typename T>
void AlgoExecutionToMarketDataListener<T>::ProcessRemove(OrderBook<T>& _data) {}

template<typename T>
void AlgoExecutionToMarketDataListener<T>::ProcessUpdate(OrderBook<T>& _data) {}

#endif
