//
//  main.cpp
//  tradingSystemYizhouWang
//
//  Created by Yizhou Wang on 12/18/22.
//

#include <iostream>
#include "marketdataservice.hpp"
#include "positionservice.hpp"
#include "pricingservice.hpp"
#include "tradebookingservice.hpp"
#include "soa.hpp"
#include "executionservice.hpp"
#include "algoexecutionservice.hpp"
#include "streamingservice.hpp"
#include "algostreamingservice.hpp"
#include "products.hpp"
#include "inquiryservice.hpp"
#include "historicaldataservice.hpp"
#include "riskservice.hpp"
#include "guiservice.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    
    PricingService<Bond> pricing;
    TradeBookingService<Bond> trade_booking;
    PositionService<Bond> position;
    RiskService<Bond> risk;
    MarketDataService<Bond> market_data;
    AlgoExecutionService<Bond> algo_execution;
    AlgoStreamingService<Bond> algo_streaming;
    GUIService<Bond> gui;
    ExecutionService<Bond> execution;
    StreamingService<Bond> streaming;
    InquiryService<Bond> inquiry;
    
    HistoricalDataService<Position<Bond>> historical_position(POSITION);
    HistoricalDataService<PV01<Bond>> historical_risk(RISK);
    HistoricalDataService<PV01<BucketedSector<Bond>>> historical_risk_bucket(RISK);
    HistoricalDataService<ExecutionOrder<Bond>> historical_execution(EXECUTION);
    HistoricalDataService<PriceStream<Bond>> historical_streaming(STREAMING);
    HistoricalDataService<Inquiry<Bond>> historical_inquiry(INQUIRY);
    
    trade_booking.AddListener(position.GetListener());
    position.AddListener(risk.GetListener());
    market_data.AddListener(algo_execution.GetListener());
    pricing.AddListener(algo_streaming.GetListener());
    pricing.AddListener(gui.GetListener());
    algo_execution.AddListener(execution.GetListener());
    execution.AddListener(trade_booking.GetListener());
    algo_streaming.AddListener(streaming.GetListener());
    
    streaming.AddListener(historical_streaming.GetListener());
    execution.AddListener(historical_execution.GetListener());
    position.AddListener(historical_position.GetListener());
    risk.AddListener(historical_risk.GetListener());
    inquiry.AddListener(historical_inquiry.GetListener());
    cout << GetCurrentTime() << " Program Initialized" << endl;

    ifstream priceData("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/prices.txt",ios::in);
    pricing.GetConnector()->Subscribe(priceData);
    cout << GetCurrentTime() << " Price Data Get" << endl;

    ifstream tradeData("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/trades.txt");
    trade_booking.GetConnector()->Subscribe(tradeData);
    cout << GetCurrentTime() << " Trades Data Get" << endl;

    ifstream marketData("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/marketdata.txt");
    market_data.GetConnector()->Subscribe(marketData);
    cout << GetCurrentTime() << " Market Data Get" << endl;

    ifstream inquiryData("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/inquiries.txt");
    inquiry.GetConnector()->Subscribe(inquiryData);
    cout << GetCurrentTime() << " Inquiries Data Get" << endl;

    cout << GetCurrentTime() << " Program Ended" << endl;
    return 0;
}
