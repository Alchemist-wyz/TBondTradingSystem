/**
 * executionservice.hpp
 * Defines the data types and Service for executions.
 *
 * @author Breman Thuraisingham
 */
#ifndef EXECUTION_SERVICE_HPP
#define EXECUTION_SERVICE_HPP

#include <string>
#include "soa.hpp"
#include "marketdataservice.hpp"
#include "algoexecutionservice.hpp"

/**
 * An execution order that can be placed on an exchange.
 * Type T is the product type.
 */
template<typename T>
class ExecutionOrder
{

public:
    
    ExecutionOrder();

  // ctor for an order
  ExecutionOrder(const T &_product, PricingSide _side, string _orderId, OrderType _orderType, double _price, double _visibleQuantity, double _hiddenQuantity, string _parentOrderId, bool _isChildOrder);

  // Get the product
  const T& GetProduct() const;

  // Get the order ID
  const string& GetOrderId() const;

  // Get the order type on this order
  OrderType GetOrderType() const;

  // Get the price on this order
  double GetPrice() const;

  // Get the visible quantity on this order
  long GetVisibleQuantity() const;

  // Get the hidden quantity
  long GetHiddenQuantity() const;

  // Get the parent order ID
  const string& GetParentOrderId() const;

  // Is child order?
  bool IsChildOrder() const;
    
    vector<string> OutPut() const;

    PricingSide GetPricingSide() const;
private:
  T product;
  PricingSide side;
  string orderId;
  OrderType orderType;
  double price;
  double visibleQuantity;
  double hiddenQuantity;
  string parentOrderId;
  bool isChildOrder;

};

/**
 * Service for executing orders on an exchange.
 * Keyed on product identifier.
 * Type T is the product type.
 */
template<typename T>
class ExecutionToAlgoExecutionListener;

template<typename T>
class ExecutionService : public Service<string,ExecutionOrder <T> >
{

public:
    ExecutionService();

    ExecutionOrder<T>& GetData(string key);

    void OnMessage(ExecutionOrder<T>& data);

    void AddListener(ServiceListener<ExecutionOrder<T>>* listener);

    const vector<ServiceListener<ExecutionOrder<T>>*>& GetListeners() const;

    ExecutionToAlgoExecutionListener<T>* GetListener();
    
    // Execute an order on a market
    void ExecuteOrder(ExecutionOrder<T>& order);
    
private:

    map<string, ExecutionOrder<T>> executionOrders;
    vector<ServiceListener<ExecutionOrder<T>>*> listeners;
    ExecutionToAlgoExecutionListener<T>* listener;


};

template<typename T>
ExecutionOrder<T>::ExecutionOrder(){}

template<typename T>
ExecutionOrder<T>::ExecutionOrder(const T &_product, PricingSide _side, string _orderId, OrderType _orderType, double _price, double _visibleQuantity, double _hiddenQuantity, string _parentOrderId, bool _isChildOrder) :
  product(_product)
{
  side = _side;
  orderId = _orderId;
  orderType = _orderType;
  price = _price;
  visibleQuantity = _visibleQuantity;
  hiddenQuantity = _hiddenQuantity;
  parentOrderId = _parentOrderId;
  isChildOrder = _isChildOrder;
}

template<typename T>
const T& ExecutionOrder<T>::GetProduct() const
{
  return product;
}

template<typename T>
const string& ExecutionOrder<T>::GetOrderId() const
{
  return orderId;
}

template<typename T>
OrderType ExecutionOrder<T>::GetOrderType() const
{
  return orderType;
}

template<typename T>
double ExecutionOrder<T>::GetPrice() const
{
  return price;
}

template<typename T>
long ExecutionOrder<T>::GetVisibleQuantity() const
{
  return visibleQuantity;
}

template<typename T>
long ExecutionOrder<T>::GetHiddenQuantity() const
{
  return hiddenQuantity;
}

template<typename T>
const string& ExecutionOrder<T>::GetParentOrderId() const
{
  return parentOrderId;
}

template<typename T>
bool ExecutionOrder<T>::IsChildOrder() const
{
  return isChildOrder;
}

template<typename T>
vector<string> ExecutionOrder<T>::OutPut() const
{
    string _product = product.GetProductId();
    string _side;
    switch (side)
    {
    case BID:
        _side = "BID";
        break;
    case OFFER:
        _side = "OFFER";
        break;
    }
    string _orderId = orderId;
    string _orderType;
    switch (orderType)
    {
    case FOK:
        _orderType = "FOK";
        break;
    case IOC:
        _orderType = "IOC";
        break;
    case MARKET:
        _orderType = "MARKET";
        break;
    case LIMIT:
        _orderType = "LIMIT";
        break;
    case STOP:
        _orderType = "STOP";
        break;
    }
    string _price = NumPriceToString(price);
    string _visibleQuantity = to_string(visibleQuantity);
    string _hiddenQuantity = to_string(hiddenQuantity);
    string _parentOrderId = parentOrderId;
    string _isChildOrder;
    switch (isChildOrder)
    {
    case true:
        _isChildOrder = "YES";
        break;
    case false:
        _isChildOrder = "NO";
        break;
    }

    vector<string> _strings;
    _strings.push_back(_product);
    _strings.push_back(_side);
    _strings.push_back(_orderId);
    _strings.push_back(_orderType);
    _strings.push_back(_price);
    _strings.push_back(_visibleQuantity);
    _strings.push_back(_hiddenQuantity);
    _strings.push_back(_parentOrderId);
    _strings.push_back(_isChildOrder);
    return _strings;
}

template<typename T>
PricingSide ExecutionOrder<T>::GetPricingSide() const
{
    return side;
}

template<typename T>
ExecutionService<T>::ExecutionService():executionOrders(), listeners(), listener(new ExecutionToAlgoExecutionListener<T>(this))
{
}

template<typename T>
ExecutionOrder<T>& ExecutionService<T>::GetData(string key)
{
    return executionOrders[key];
}

template<typename T>
void ExecutionService<T>::OnMessage(ExecutionOrder<T>& data)
{
    executionOrders[data.GetProduct().GetProductId()] = data;
}

template<typename T>
void ExecutionService<T>::AddListener(ServiceListener<ExecutionOrder<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<ExecutionOrder<T>>*>& ExecutionService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
ExecutionToAlgoExecutionListener<T>* ExecutionService<T>::GetListener()
{
    return listener;
}

template<typename T>
void ExecutionService<T>::ExecuteOrder(ExecutionOrder<T>& executionOrder)
{
    executionOrders[executionOrder.GetProduct().GetProductId()] = executionOrder;

    for (auto& l : listeners) l->ProcessAdd(executionOrder);
}

template<typename T>
class ExecutionToAlgoExecutionListener : public ServiceListener<AlgoExecution<T>>
{

private:

    ExecutionService<T>* service;

public:
    ExecutionToAlgoExecutionListener(ExecutionService<T>* service);
    
    void ProcessAdd(AlgoExecution<T>& data);

    void ProcessRemove(AlgoExecution<T>& data);

    void ProcessUpdate(AlgoExecution<T>& data);

};

template<typename T>
ExecutionToAlgoExecutionListener<T>::ExecutionToAlgoExecutionListener(ExecutionService<T>* service): service(service)
{
}

template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessAdd(AlgoExecution<T>& data)
{
    service->OnMessage(*data.GetExecutionOrder());
    service->ExecuteOrder(*data.GetExecutionOrder());
}

template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessRemove(AlgoExecution<T>& data) {}

template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessUpdate(AlgoExecution<T>& data) {}

#endif
