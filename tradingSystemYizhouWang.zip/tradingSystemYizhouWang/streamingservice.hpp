/**
 * streamingservice.hpp
 * Defines the data types and Service for price streams.
 *
 * @author Breman Thuraisingham
 */
#ifndef STREAMING_SERVICE_HPP
#define STREAMING_SERVICE_HPP

#include "soa.hpp"
#include "marketdataservice.hpp"
#include "algostreamingservice.hpp"

//class PriceStreamOrder
//{
//
//public:
//
//    PriceStreamOrder(double price, long visibleq, long hiddenq, PricingSide side);
//
//    double GetPrice() const;
//
//    long GetVisibleQuantity() const;
//
//    long GetHiddenQuantity() const;
//
//    PricingSide GetSide() const;
//
//    vector<string> OutPut() const;
//
//private:
//    double price;
//    long visibleQuantity;
//    long hiddenQuantity;
//    PricingSide side;
//
//};

PriceStreamOrder::PriceStreamOrder(double price, long visibleq, long hiddenq, PricingSide side):price(price), visibleQuantity(visibleq), hiddenQuantity(hiddenq), side(side)
{
}

double PriceStreamOrder::GetPrice() const
{
    return price;
}

long PriceStreamOrder::GetVisibleQuantity() const
{
    return visibleQuantity;
}

long PriceStreamOrder::GetHiddenQuantity() const
{
    return hiddenQuantity;
}

PricingSide PriceStreamOrder::GetSide() const
{
    return side;
}

vector<string> PriceStreamOrder::OutPut() const
{
    string _price = NumPriceToString(price);
    string _visibleQuantity = to_string(visibleQuantity);
    string _hiddenQuantity = to_string(hiddenQuantity);
    string _side;
    switch (side)
    {
    case BID:
        _side = "BID";
        break;
    case OFFER:
        _side = "OFFER";
        break;
    }

    vector<string> _strings;
    _strings.push_back(_price);
    _strings.push_back(_visibleQuantity);
    _strings.push_back(_hiddenQuantity);
    _strings.push_back(_side);
    return _strings;
}

template<typename T>
class PriceStream
{

public:
    
    PriceStream();

    PriceStream(const T& product, const PriceStreamOrder& bid, const PriceStreamOrder& offer);

    const T& GetProduct() const;

    const PriceStreamOrder& GetBidOrder() const;

    const PriceStreamOrder& GetOfferOrder() const;
    
    vector<string> OutPut() const;

private:
    T product;
    PriceStreamOrder bidOrder;
    PriceStreamOrder offerOrder;

};

template<typename T>
PriceStream<T>::PriceStream(){}

template<typename T>
PriceStream<T>::PriceStream(const T& product, const PriceStreamOrder& bidOrder, const PriceStreamOrder& offerOrder) :
    product(product), bidOrder(bidOrder), offerOrder(offerOrder)
{
}

template<typename T>
const T& PriceStream<T>::GetProduct() const
{
    return product;
}

template<typename T>
const PriceStreamOrder& PriceStream<T>::GetBidOrder() const
{
    return bidOrder;
}

template<typename T>
const PriceStreamOrder& PriceStream<T>::GetOfferOrder() const
{
    return offerOrder;
}


template<typename T>
vector<string> PriceStream<T>::OutPut() const
{
    string _product = product.GetProductId();
    vector<string> _bidOrder = bidOrder.OutPut();
    vector<string> _offerOrder = offerOrder.OutPut();

    vector<string> _strings;
    _strings.push_back(_product);
    _strings.insert(_strings.end(), _bidOrder.begin(), _bidOrder.end());
    _strings.insert(_strings.end(), _offerOrder.begin(), _offerOrder.end());
    return _strings;
}


template<typename T>
class StreamingToAlgoStreamingListener;


template<typename T>
class StreamingService : public Service<string, PriceStream<T>>
{

private:

    map<string, PriceStream<T>> priceStreams;
    vector<ServiceListener<PriceStream<T>>*> listeners;
    ServiceListener<AlgoStream<T>>* listener;

public:

    // Constructor and destructor
    StreamingService();
    ~StreamingService();

    // Get data on our service given a key
    PriceStream<T>& GetData(string _key);

    // The callback that a Connector should invoke for any new or updated data
    void OnMessage(PriceStream<T>& _data);

    // Add a listener to the Service for callbacks on add, remove, and update events for data to the Service
    void AddListener(ServiceListener<PriceStream<T>>* _listener);

    // Get all listeners on the Service
    const vector<ServiceListener<PriceStream<T>>*>& GetListeners() const;

    // Get the listener of the service
    ServiceListener<AlgoStream<T>>* GetListener();

    // Publish two-way prices
    void PublishPrice(PriceStream<T>& _priceStream);

};

template<typename T>
StreamingService<T>::StreamingService()
{
    priceStreams = map<string, PriceStream<T>>();
    listeners = vector<ServiceListener<PriceStream<T>>*>();
    listener = new StreamingToAlgoStreamingListener<T>(this);
}

template<typename T>
StreamingService<T>::~StreamingService() {}

template<typename T>
PriceStream<T>& StreamingService<T>::GetData(string _key)
{
    return priceStreams[_key];
}

template<typename T>
void StreamingService<T>::OnMessage(PriceStream<T>& _data)
{
    priceStreams[_data.GetProduct().GetProductId()] = _data;
}

template<typename T>
void StreamingService<T>::AddListener(ServiceListener<PriceStream<T>>* _listener)
{
    listeners.push_back(_listener);
}

template<typename T>
const vector<ServiceListener<PriceStream<T>>*>& StreamingService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
ServiceListener<AlgoStream<T>>* StreamingService<T>::GetListener()
{
    return listener;
}

template<typename T>
void StreamingService<T>::PublishPrice(PriceStream<T>& _priceStream)
{
    for (auto& l : listeners)
    {
        l->ProcessAdd(_priceStream);
    }
}

template<typename T>
class StreamingToAlgoStreamingListener : public ServiceListener<AlgoStream<T>>
{

private:

    StreamingService<T>* service;

public:

    // Connector and Destructor
    StreamingToAlgoStreamingListener(StreamingService<T>* _service);
    ~StreamingToAlgoStreamingListener();

    // Listener callback to process an add event to the Service
    void ProcessAdd(AlgoStream<T>& _data);

    // Listener callback to process a remove event to the Service
    void ProcessRemove(AlgoStream<T>& _data);

    // Listener callback to process an update event to the Service
    void ProcessUpdate(AlgoStream<T>& _data);

};

template<typename T>
StreamingToAlgoStreamingListener<T>::StreamingToAlgoStreamingListener(StreamingService<T>* _service)
{
    service = _service;
}

template<typename T>
StreamingToAlgoStreamingListener<T>::~StreamingToAlgoStreamingListener() {}

template<typename T>
void StreamingToAlgoStreamingListener<T>::ProcessAdd(AlgoStream<T>& _data)
{
    PriceStream<T>* _priceStream = _data.GetPriceStream();
    service->OnMessage(*_priceStream);
    service->PublishPrice(*_priceStream);
}

template<typename T>
void StreamingToAlgoStreamingListener<T>::ProcessRemove(AlgoStream<T>& _data) {}

template<typename T>
void StreamingToAlgoStreamingListener<T>::ProcessUpdate(AlgoStream<T>& _data) {}

#endif
