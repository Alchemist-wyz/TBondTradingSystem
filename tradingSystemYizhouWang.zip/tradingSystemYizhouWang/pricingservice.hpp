/**
 * pricingservice.hpp
 * Defines the data types and Service for internal prices.
 *
 * @author Breman Thuraisingham
 */
#ifndef PRICING_SERVICE_HPP
#define PRICING_SERVICE_HPP

#include <string>
#include "soa.hpp"

/**
 * A price object consisting of mid and bid/offer spread.
 * Type T is the product type.
 */
template<typename T>
class Price
{

public:
    
    Price():product(),mid(),bidOfferSpread(){}

  // ctor for a price
  Price(T &_product, double _mid, double _bidOfferSpread);

    Price<T>& operator=(const Price<T>& data);

  // Get the product
  const T& GetProduct() const;

  // Get the mid price
  double GetMid() const;

  // Get the bid/offer spread around the mid
  double GetBidOfferSpread() const;

    vector<string> OutPut() const;
private:
  T product;
  double mid;
  double bidOfferSpread;

};

/**
 * Pricing Service managing mid prices and bid/offers.
 * Keyed on product identifier.
 * Type T is the product type.
 */

template<typename T>
class PricingConnector;

template<typename T>
class PricingService : public Service<string,Price <T> >
{
public:

    // Constructor and destructor
    PricingService();

    Price<T>& GetData(string key);

    void OnMessage(Price<T>& data);

    void AddListener(ServiceListener<Price<T>>* listener);

    const vector<ServiceListener<Price<T>>*>& GetListeners() const;

    PricingConnector<T>* GetConnector();
    
private:

    map<string, Price<T>> prices;
    vector<ServiceListener<Price<T>>*> listeners;
    PricingConnector<T>* connector;
};

template<typename T>
Price<T>::Price(T &_product, double _mid, double _bidOfferSpread) :
  product(_product)
{
  mid = _mid;
  bidOfferSpread = _bidOfferSpread;
}

template<typename T>
Price<T>& Price<T>::operator=(const Price<T>& data){
    this->mid = data.mid;
    this->bidOfferSpread = data.bidOfferSpread;
    this->product = data.product;
    return *this;
}

template<typename T>
const T& Price<T>::GetProduct() const
{
  return product;
}

template<typename T>
double Price<T>::GetMid() const
{
  return mid;
}

template<typename T>
double Price<T>::GetBidOfferSpread() const
{
  return bidOfferSpread;
}

template<typename T>
vector<string> Price<T>::OutPut() const
{
    string _product = product.GetProductId();
    string _mid = NumPriceToString(mid);
    string _bidOfferSpread = NumPriceToString(bidOfferSpread);

    vector<string> _strings;
    _strings.push_back(_product);
    _strings.push_back(_mid);
    _strings.push_back(_bidOfferSpread);
    return _strings;
}

template<typename T>
PricingService<T>::PricingService(): prices(), listeners(), connector(new PricingConnector<T>(this))
{
}

template<typename T>
Price<T>& PricingService<T>::GetData(string key)
{
    return prices[key];
}

template<typename T>
void PricingService<T>::OnMessage(Price<T>& data)
{
    prices[data.GetProduct().GetProductId()] = data;

    for (auto& l : listeners) l->ProcessAdd(data);
}

template<typename T>
void PricingService<T>::AddListener(ServiceListener<Price<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<Price<T>>*>& PricingService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
PricingConnector<T>* PricingService<T>::GetConnector()
{
    return connector;
}

template<typename T>
class PricingConnector : public Connector<Price<T>>
{

private:

    PricingService<T>* service;

public:

    PricingConnector(PricingService<T>* service);

    void Publish(Price<T>& data);

    void Subscribe(ifstream& data);

};

template<typename T>
PricingConnector<T>::PricingConnector(PricingService<T>* service): service(service)
{
}

template<typename T>
void PricingConnector<T>::Publish(Price<T>& data) {}

template<typename T>
void PricingConnector<T>::Subscribe(ifstream& data)
{
    string _line;
    while (getline(data, _line))
    {
        stringstream _lineStream(_line);
        string _cell;
        vector<string> _cells;
        while (getline(_lineStream, _cell, ','))
        {
            _cells.push_back(_cell);
        }
        string _productId = _cells[0];
        double _bidPrice = StringPriceToNum(_cells[1]);
        double _offerPrice = StringPriceToNum(_cells[2]);
        double _midPrice = (_bidPrice + _offerPrice) / 2.0;
        double _spread = _offerPrice - _bidPrice;
        T _product = GetTreasuryFromCUSIP(_productId);
        Price<T> _price(_product, _midPrice, _spread);
        service->OnMessage(_price);
    }
}


#endif
