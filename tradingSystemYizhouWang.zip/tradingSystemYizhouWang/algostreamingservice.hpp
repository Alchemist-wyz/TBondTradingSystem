#ifndef ALGO_STREAMING_SERVICE_HPP
#define ALGO_STREAMING_SERVICE_HPP

#include <string>
#include "soa.hpp"
#include "pricingservice.hpp"
#include "streamingservice.hpp"

class PriceStreamOrder
{

public:
    PriceStreamOrder(){}

    PriceStreamOrder(double price, long visibleq, long hiddenq, PricingSide side);

    double GetPrice() const;

    long GetVisibleQuantity() const;

    long GetHiddenQuantity() const;

    PricingSide GetSide() const;
    
    vector<string> OutPut() const;

private:
    double price;
    long visibleQuantity;
    long hiddenQuantity;
    PricingSide side;

};

template <typename T>
class PriceStream;

template<typename T>
class AlgoStream
{

public:
    
    AlgoStream();
    
	AlgoStream(const T& product, const PriceStreamOrder& bidOrder, const PriceStreamOrder& offerOrder);

	// Get the order
	PriceStream<T>* GetPriceStream() const;

private:
	PriceStream<T>* priceStream;

};

template<typename T>
AlgoStream<T>::AlgoStream(){}

template<typename T>
AlgoStream<T>::AlgoStream(const T& product, const PriceStreamOrder& bidOrder, const PriceStreamOrder& offerOrder):priceStream(new PriceStream (product, bidOrder, offerOrder) )
{
}

template<typename T>
PriceStream<T>* AlgoStream<T>::GetPriceStream() const
{
	return priceStream;
}


template<typename T>
class AlgoStreamingToPricingListener;


template<typename T>
class AlgoStreamingService : public Service<string, AlgoStream<T>>
{

private:

	map<string, AlgoStream<T>> algo_stream;
	vector<ServiceListener<AlgoStream<T>>*> listeners;
	ServiceListener<Price<T>>* listener;
	long count;

public:

	AlgoStreamingService();

	AlgoStream<T>& GetData(string key);

	void OnMessage(AlgoStream<T>& data);

	void AddListener(ServiceListener<AlgoStream<T>>* listener);

	const vector<ServiceListener<AlgoStream<T>>*>& GetListeners() const;

	ServiceListener<Price<T>>* GetListener();

	void AlgoPublishPrice(Price<T>& _price);

};

template<typename T>
AlgoStreamingService<T>::AlgoStreamingService():algo_stream(),listeners(),listener(new AlgoStreamingToPricingListener<T>(this)),count(0)
{
}

template<typename T>
AlgoStream<T>& AlgoStreamingService<T>::GetData(string key)
{
	return algo_stream[key];
}

template<typename T>
void AlgoStreamingService<T>::OnMessage(AlgoStream<T>& data)
{
	algo_stream[data.GetPriceStream()->GetProduct().GetProductId()] = data;
}

template<typename T>
void AlgoStreamingService<T>::AddListener(ServiceListener<AlgoStream<T>>* listener)
{
	listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<AlgoStream<T>>*>& AlgoStreamingService<T>::GetListeners() const
{
	return listeners;
}

template<typename T>
ServiceListener<Price<T>>* AlgoStreamingService<T>::GetListener()
{
	return listener;
}

template<typename T>
void AlgoStreamingService<T>::AlgoPublishPrice(Price<T>& price)
{
	T prod = price.GetProduct();
	auto mid = price.GetMid();
	auto spread = price.GetBidOfferSpread();
    
	long visible = (count%2 + 1)*1000000;
	long hidden = visible*2;

	PriceStreamOrder bid_order(mid - spread/2., visible, hidden, BID);
	PriceStreamOrder offer_order(mid + spread/2., visible, hidden, OFFER);
	AlgoStream<T> algo(prod, bid_order, offer_order);
	algo_stream[prod.GetProductId()] = algo;

	for (auto& l : listeners)l->ProcessAdd(algo);
    
    count++;
}


template<typename T>
class AlgoStreamingToPricingListener : public ServiceListener<Price<T>>
{

private:

	AlgoStreamingService<T>* service;

public:

	AlgoStreamingToPricingListener(AlgoStreamingService<T>* service);

	void ProcessAdd(Price<T>& data);

	void ProcessRemove(Price<T>& data);

	void ProcessUpdate(Price<T>& data);

};

template<typename T>
AlgoStreamingToPricingListener<T>::AlgoStreamingToPricingListener(AlgoStreamingService<T>* service):service(service)
{
}

template<typename T>
void AlgoStreamingToPricingListener<T>::ProcessAdd(Price<T>& data)
{
	service->AlgoPublishPrice(data);
}

template<typename T>
void AlgoStreamingToPricingListener<T>::ProcessRemove(Price<T>& data) {}

template<typename T>
void AlgoStreamingToPricingListener<T>::ProcessUpdate(Price<T>& data) {}

#endif
