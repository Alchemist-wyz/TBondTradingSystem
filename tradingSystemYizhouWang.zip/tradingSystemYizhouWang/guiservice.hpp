#ifndef GUI_SERVICE_HPP
#define GUI_SERVICE_HPP

#include "soa.hpp"
#include "pricingservice.hpp"

template<typename T>
class GUIConnector;

template<typename T>
class GUIToPricingListener;


template<typename T>
class GUIService : Service<string, Price<T>>
{

private:

	map<string, Price<T>> guis;
	vector<ServiceListener<Price<T>>*> listeners;
	GUIConnector<T>* connector;
	ServiceListener<Price<T>>* listener;
	int throttle;
	long millisec;

public:

	GUIService();

	Price<T>& GetData(string _key);

	void OnMessage(Price<T>& _data);

	void AddListener(ServiceListener<Price<T>>* listener);

	const vector<ServiceListener<Price<T>>*>& GetListeners() const;

	GUIConnector<T>* GetConnector();

	ServiceListener<Price<T>>* GetListener();

	int GetThrottle() const;

	long GetMillisec() const;

	void SetMillisec(long millisec);

};

template<typename T>
GUIService<T>::GUIService(): guis(), listeners(), throttle(300), millisec(0), connector(new GUIConnector<T>(this)), listener(new GUIToPricingListener<T>(this))
{
}

template<typename T>
Price<T>& GUIService<T>::GetData(string key)
{
	return guis[key];
}

template<typename T>
void GUIService<T>::OnMessage(Price<T>& data)
{
	guis[data.GetProduct().GetProductId()] = data;
	connector->Publish(data);
}

template<typename T>
void GUIService<T>::AddListener(ServiceListener<Price<T>>* listener)
{
	listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<Price<T>>*>& GUIService<T>::GetListeners() const
{
	return listeners;
}

template<typename T>
GUIConnector<T>* GUIService<T>::GetConnector()
{
	return connector;
}

template<typename T>
ServiceListener<Price<T>>* GUIService<T>::GetListener()
{
	return listener;
}

template<typename T>
int GUIService<T>::GetThrottle() const
{
	return throttle;
}

template<typename T>
long GUIService<T>::GetMillisec() const
{
	return millisec;
}

template<typename T>
void GUIService<T>::SetMillisec(long millisec)
{
	millisec = millisec;
}


template<typename T>
class GUIConnector : public Connector<Price<T>>
{

private:

	GUIService<T>* service;

public:

	GUIConnector(GUIService<T>* service);

	void Publish(Price<T>& data);

	void Subscribe(ifstream& data);
};

template<typename T>
GUIConnector<T>::GUIConnector(GUIService<T>* service):service(service)
{
}

template<typename T>
void GUIConnector<T>::Publish(Price<T>& data)
{
	long milli = service->GetMillisec();
	long milli_now = GetCurrentMillisecond();
//	while (milli_now < milli) milli_now = GetCurrentMillisecond();
	if (milli_now - milli > service->GetThrottle())
	{
		service->SetMillisec(milli_now);
		ofstream f;
		f.open("gui.txt", ios::app); f << GetCurrentTime() << ", ";
        
		vector<string> outputs = data.OutPut();
		for (auto& s : outputs) f << s << ", ";
		f << endl;
	}
}

template<typename T>
void GUIConnector<T>::Subscribe(ifstream& data) {}



template<typename T>
class GUIToPricingListener : public ServiceListener<Price<T>>
{

private:

	GUIService<T>* service;

public:

	GUIToPricingListener(GUIService<T>* service);

	void ProcessAdd(Price<T>& data);

	void ProcessRemove(Price<T>& data);

	void ProcessUpdate(Price<T>& data);

};

template<typename T>
GUIToPricingListener<T>::GUIToPricingListener(GUIService<T>* service):service(service)
{
}


template<typename T>
void GUIToPricingListener<T>::ProcessAdd(Price<T>& data)
{
	service->OnMessage(data);
}

template<typename T>
void GUIToPricingListener<T>::ProcessRemove(Price<T>& data) {}

template<typename T>
void GUIToPricingListener<T>::ProcessUpdate(Price<T>& data) {}

#endif
