/**
 * historicaldataservice.hpp
 * historicaldataservice.hpp
 *
 * @author Breman Thuraisingham
 * Defines the data types and Service for historical data.
 *
 * @author Breman Thuraisingham
 */
#ifndef HISTORICAL_DATA_SERVICE_HPP
#define HISTORICAL_DATA_SERVICE_HPP


#include "soa.hpp"
#include "riskservice.hpp"
enum ServiceType { POSITION, RISK, EXECUTION, STREAMING, INQUIRY };

/**
 * Service for processing and persisting historical data to a persistent store.
 * Keyed on some persistent key.
 * Type T is the data type to persist.
 */
template<typename T>
class HistoricalDataConnector;

template<typename T>
class HistoricalDataListener;

template<typename T>
class HistoricalDataService : Service<string,T>
{

public:
    HistoricalDataService(ServiceType type);

    T& GetData(string key);

    void OnMessage(T& data);

    void AddListener(ServiceListener<T>* listener);

    const vector<ServiceListener<T>*>& GetListeners() const;

    HistoricalDataConnector<T>* GetConnector();

    ServiceListener<T>* GetListener();

    ServiceType GetServiceType() const;
    
  // Persist data to a store
  void PersistData(T& data);
    
private:

    map<string, T> historicalDatas;
    vector<ServiceListener<T>*> listeners;
    HistoricalDataConnector<T>* connector;
    ServiceListener<T>* listener;
    ServiceType type;
};


template<typename T>
HistoricalDataService<T>::HistoricalDataService(ServiceType type):type(type),connector(new HistoricalDataConnector<T>(this)),listener(new HistoricalDataListener<T>(this))
{
}

template<typename T>
T& HistoricalDataService<T>::GetData(string key)
{
    return historicalDatas[key];
}

template<typename T>
void HistoricalDataService<T>::OnMessage(T& data)
{
    historicalDatas[data.GetProduct().GetProductId()] = data;
}

template<typename T>
void HistoricalDataService<T>::AddListener(ServiceListener<T>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<T>*>& HistoricalDataService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
HistoricalDataConnector<T>* HistoricalDataService<T>::GetConnector()
{
    return connector;
}

template<typename T>
ServiceListener<T>* HistoricalDataService<T>::GetListener()
{
    return listener;
}

template<typename T>
ServiceType HistoricalDataService<T>::GetServiceType() const
{
    return type;
}

template<typename T>
void HistoricalDataService<T>::PersistData(T& data)
{
    connector->Publish(data);
}


template<typename T>
class HistoricalDataConnector : public Connector<T>
{

private:

    HistoricalDataService<T>* service;

public:

    HistoricalDataConnector(HistoricalDataService<T>* service);

    void Publish(T& data);

    void Subscribe(ifstream& data);

};

template<typename T>
HistoricalDataConnector<T>::HistoricalDataConnector(HistoricalDataService<T>* service):service(service)
{
}

template<typename T>
void HistoricalDataConnector<T>::Publish(T& data)
{
    ServiceType type = service->GetServiceType();
    ofstream f;
    if(type == POSITION) f.open("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/positions.txt", ios::app);
    else if(type == RISK) f.open("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/risk.txt", ios::app);
    else if(type == EXECUTION) f.open("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/executions.txt", ios::app);
    else if(type == STREAMING) f.open("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/streaming.txt", ios::app);
    else if(type == INQUIRY) f.open("/Users/wangyizhou/Desktop/tradingSystemYizhouWang/tradingSystemYizhouWang/allinquiries.txt", ios::app);

    f<< GetCurrentTime() << ", ";
    for (auto& s : data.OutPut()) f << s << ", "; f << endl;
//    if (type == RISK){
//        vector<Bond> front_end;
//        front_end.push_back(GetTreasuryFromCUSIP("91282CFX4"));
//        front_end.push_back(GetTreasuryFromCUSIP("91282CFW6"));
//        BucketedSector<Bond> front_end_bucket (front_end, "FrontEnd");
//        
//        vector<Bond> belly;
//        belly.push_back(GetTreasuryFromCUSIP("91282CFZ9"));
//        belly.push_back(GetTreasuryFromCUSIP("91282CFY2"));
//        belly.push_back(GetTreasuryFromCUSIP("91282CFV8"));
//        BucketedSector<Bond> belly_bucket (belly, "Belly");
//        
//        vector<Bond> long_end;
//        long_end.push_back(GetTreasuryFromCUSIP("912810TM0"));
//        long_end.push_back(GetTreasuryFromCUSIP("912810TL2"));
//
//        service->GetListener()->GetBucketedRisk().OutPut();
//    }
}

template<typename T>
void HistoricalDataConnector<T>::Subscribe(ifstream& data) {}


template<typename T>
class HistoricalDataListener : public ServiceListener<T>
{
public:

    HistoricalDataListener(HistoricalDataService<T>* service);

    void ProcessAdd(T& data);

    void ProcessRemove(T& data);

    void ProcessUpdate(T& data);
    
private:

    HistoricalDataService<T>* service;

};

template<typename T>
HistoricalDataListener<T>::HistoricalDataListener(HistoricalDataService<T>* service): service(service)
{
}

template<typename T>
void HistoricalDataListener<T>::ProcessAdd(T& data)
{
    service->PersistData(data);
}

template<typename V>
void HistoricalDataListener<V>::ProcessRemove(V& data) {}

template<typename V>
void HistoricalDataListener<V>::ProcessUpdate(V& data) {}


#endif
