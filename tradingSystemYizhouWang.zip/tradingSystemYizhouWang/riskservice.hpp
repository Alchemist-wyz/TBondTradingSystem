/**
 * riskservice.hpp
 * Defines the data types and Service for fixed income risk.
 *
 * @author Breman Thuraisingham
 */
#ifndef RISK_SERVICE_HPP
#define RISK_SERVICE_HPP

#include "soa.hpp"
#include "products.hpp"
#include "positionservice.hpp"

/**
 * PV01 risk.
 * Type T is the product type.
 */
template<typename T>
class PV01
{

public:
    
    PV01();

  // ctor for a PV01 value
  PV01(const T &product, double pv01, long quantity);

  // Get the product on this PV01 value
  const T& GetProduct() const;

  // Get the PV01 value
  double GetPV01() const;

  // Get the quantity that this risk value is associated with
  long GetQuantity() const;
    
    void SetQuantity(long quantity);

    vector<string> OutPut() const;

private:
  T product;
  double pv01;
  long quantity;

};

/**
 * A bucket sector to bucket a group of securities.
 * We can then aggregate bucketed risk to this bucket.
 * Type T is the product type.
 */
template<typename T>
class BucketedSector
{

public:
    BucketedSector(){}
  // ctor for a bucket sector
  BucketedSector(const vector<T> &_products, string _name);

  // Get the products associated with this bucket
  const vector<T>& GetProducts() const;

  // Get the name of the bucket
  const string& GetName() const;
    
    string GetProductId() const;

private:
  vector<T> products;
  string name;

};

/**
 * Risk Service to vend out risk for a particular security and across a risk bucketed sector.
 * Keyed on product identifier.
 * Type T is the product type.
 */
template<typename T>
class RiskToPositionListener;

template<typename T>
class RiskService : public Service<string,PV01 <T> >
{

public:
    
    RiskService();

    PV01<T>& GetData(string key);

    void OnMessage(PV01<T>& data);

    void AddListener(ServiceListener<PV01<T>>* listener);

    const vector<ServiceListener<PV01<T>>*>& GetListeners() const;

    RiskToPositionListener<T>* GetListener();

  // Add a position that the service will risk
  void AddPosition(Position<T> &position);

  // Get the bucketed risk for the bucket sector
  const PV01< BucketedSector<T> >& GetBucketedRisk(const BucketedSector<T> &sector) const;
    
private:

    map<string, PV01<T>> pv01s;
    vector<ServiceListener<PV01<T>>*> listeners;
    RiskToPositionListener<T>* listener;
};

template<typename T>
PV01<T>::PV01(){}

template<typename T>
PV01<T>::PV01(const T &_product, double _pv01, long _quantity) :
  product(_product)
{
  pv01 = _pv01;
  quantity = _quantity;
}

template<typename T>
const T& PV01<T>::GetProduct() const
{
    return product;
}

template<typename T>
double PV01<T>::GetPV01() const
{
    return pv01;
}

template<typename T>
long PV01<T>::GetQuantity() const
{
    return quantity;
}

template<typename T>
void PV01<T>::SetQuantity(long quantity)
{
    quantity = quantity;
}

template<typename T>
vector<string> PV01<T>::OutPut() const
{
    
    string _product = product.GetProductId();
    string _pv01 = to_string(pv01);
    string _quantity = to_string(quantity);

    vector<string> _strings;
    _strings.push_back(_product);
    _strings.push_back(_pv01);
    _strings.push_back(_quantity);
    return _strings;
}

template<typename T>
BucketedSector<T>::BucketedSector(const vector<T>& _products, string _name) :
  products(_products)
{
  name = _name;
}

template<typename T>
const vector<T>& BucketedSector<T>::GetProducts() const
{
  return products;
}

template<typename T>
const string& BucketedSector<T>::GetName() const
{
  return name;
}

template<typename T>
string BucketedSector<T>::GetProductId()const{return name;}

template<typename T>
RiskService<T>::RiskService():pv01s(),listeners(), listener(new RiskToPositionListener<T>(this))
{
}

template<typename T>
PV01<T>& RiskService<T>::GetData(string key)
{
    return pv01s[key];
}

template<typename T>
void RiskService<T>::OnMessage(PV01<T>& data)
{
    pv01s[data.GetProduct().GetProductId()] = data;
}

template<typename T>
void RiskService<T>::AddListener(ServiceListener<PV01<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<PV01<T>>*>& RiskService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
RiskToPositionListener<T>* RiskService<T>::GetListener()
{
    return listener;
}

template<typename T>
void RiskService<T>::AddPosition(Position<T>& pos)
{
    T prod = pos.GetProduct();
    string prod_id = prod.GetProductId();
    PV01<T> pv01(prod, GetPV01Value(prod_id), pos.GetAggregatePosition());
    pv01s[prod_id] = pv01;
    for (auto& l : listeners) l->ProcessAdd(pv01);
    
    T frontend ("FrontEnd", CUSIP, "FrontEnd", 0, from_string("1900/01/01"));
    T belly ("Belly", CUSIP, "Belly", 0, from_string("1900/01/01"));
    T longend ("LongEnd", CUSIP, "LongEnd", 0, from_string("1900/01/01"));
    
    PV01<T> pv01_frontend (frontend, pv01s["91282CFX4"].GetPV01()*pv01s["91282CFX4"].GetQuantity() + pv01s["91282CFW6"].GetPV01()*pv01s["91282CFW6"].GetQuantity(),1);
    PV01<T> pv01_belly (belly,
        pv01s["91282CFZ9"].GetPV01()*pv01s["91282CFZ9"].GetQuantity() + pv01s["91282CFV8"].GetPV01()*pv01s["91282CFV8"].GetQuantity() + pv01s["91282CFY2"].GetPV01()*pv01s["91282CFY2"].GetQuantity(),1);
    PV01<T> pv01_longend (longend, pv01s["912810TM0"].GetPV01()*pv01s["912810TM0"].GetQuantity() + pv01s["912810TL2"].GetPV01()*pv01s["912810TL2"].GetQuantity(),1);
    
    for (auto& l : listeners) {l->ProcessAdd(pv01_frontend);l->ProcessAdd(pv01_belly);
        l->ProcessAdd(pv01_longend);}
}

template<typename T>
const PV01<BucketedSector<T>>& RiskService<T>::GetBucketedRisk(const BucketedSector<T>& sector) const
{
    BucketedSector<T> copied = sector;
    double pv01 = 0;

    vector<T>& prods = sector.GetProducts();
    for (auto& p : prods) pv01 += pv01s[p.GetProductId()].GetPV01()*pv01s[p.GetProductId()].GetQuantity();

    return PV01<BucketedSector<T>>(copied, pv01, 1);
}

template<typename T>
class RiskToPositionListener : public ServiceListener<Position<T>>
{

public:

    RiskToPositionListener(RiskService<T>* service);

    void ProcessAdd(Position<T>& data);

    void ProcessRemove(Position<T>& data);

    void ProcessUpdate(Position<T>& data);
    
private:

    RiskService<T>* service;


};

template<typename T>
RiskToPositionListener<T>::RiskToPositionListener(RiskService<T>* service):service(service)
{
}


template<typename T>
void RiskToPositionListener<T>::ProcessAdd(Position<T>& data)
{
    service->AddPosition(data);
}

template<typename T>
void RiskToPositionListener<T>::ProcessRemove(Position<T>& data) {}

template<typename T>
void RiskToPositionListener<T>::ProcessUpdate(Position<T>& data) {}

#endif
