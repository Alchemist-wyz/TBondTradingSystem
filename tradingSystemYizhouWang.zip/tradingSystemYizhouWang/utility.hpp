#ifndef UTILITY_HPP
#define UTILITY_HPP

#include <iostream>
#include <chrono>
#include <string>
#include <random>
#include "products.hpp"

using namespace std;
using namespace chrono;

default_random_engine generator;
uniform_int_distribution<int> distribution(0,25);


Bond GetTreasuryFromCUSIP(string cusip)
{
    Bond T ("",CUSIP,"",0,from_string("1900/01/01"));
    if (cusip == "91282CFX4") T = Bond("91282CFX4", CUSIP, "US2Y", 0.045, from_string("2024/11/30"));
	else if (cusip == "91282CFW6") T = Bond("91282CFW6", CUSIP, "US3Y", 0.045, from_string("2025/11/15"));
	else if (cusip == "91282CFZ9") T = Bond("91282CFZ9", CUSIP, "US5Y", 0.03875, from_string("2027/11/30"));
	else if (cusip == "91282CFY2") T = Bond("91282CFY2", CUSIP, "US7Y", 0.03875, from_string("2029/11/30"));
	else if (cusip == "91282CFV8") T = Bond("91282CFV8", CUSIP, "US10Y", 0.04125, from_string("2032/11/15"));
	else if (cusip == "912810TM0") T = Bond("912810TM0", CUSIP, "US20Y", 0.04, from_string("2042/11/15"));
    else if (cusip == "912810TL2") T = Bond("912810TL2", CUSIP, "US30Y", 0.04, from_string("2052/11/15"));
	return T;
}

double GetPV01Value(string cusip)
{
	double res = 0.;
	if (cusip == "91282CFX4") res = 0.01879;
	else if (cusip == "91282CFW6") res = 0.02761;
	else if (cusip == "91282CFZ9") res = 0.04526;
	else if (cusip == "91282CFY2") res = 0.06170;
	else if (cusip == "91282CFV8") res = 0.08598;
	else if (cusip == "912810TM0") res = 0.14420;
    else if (cusip == "912810TL2") res = 0.19917;
	return res;
}

double StringPriceToNum(string input)
{
    int flag = 0;
    
	string first_part = "";
	string second_part = "";
	string third_part = "";

	for (auto c:input){
		if (c == '-'){
			flag++;
			continue;
		}
		
        if(flag==0) first_part.push_back(c);
        
        else if(flag==1){
            second_part.push_back(c);
            flag++;
        }
        else if(flag==2){
            second_part.push_back(c);
            flag++;
        }
        else if(flag==3){
            if (c == '+') c = '4';
            third_part.push_back(c);
        }
    }

	double first_value = stod(first_part);
	double second_value = stod(second_part);
	double third_value = stod(third_part);

    return first_value + second_value/32. + third_value/256.;
}

string NumPriceToString(double input)
{
	int first_part = floor(input);
	int residual = floor((input - first_part)*256.);
	int second_part = floor(residual/8.0);
	int third_part = residual%8;

	string first_part_string = to_string(first_part);
    
	string second_part_string = to_string(second_part);
	if (second_part < 10) second_part_string = "0" + second_part_string;
    
    string third_part_string = to_string(third_part);
	if (third_part == 4) third_part_string = "+";

    return first_part_string + "-" + second_part_string + third_part_string;
}

string GetCurrentTime()
{
    auto now = system_clock::now();
    
	auto milli = chrono::duration_cast<chrono::milliseconds>(now - chrono::time_point_cast<chrono::seconds>(now));
	auto milli_count = milli.count();
    
	string milli_string = to_string(milli_count);
	if(milli_count < 10) milli_string = "00" + milli_string;
	else if(milli_count < 100) milli_string = "0" + milli_string;

	time_t now_ = system_clock::to_time_t(now);
	char time_string[30];
	strftime(time_string, 24, "%F [%T", localtime(&now_));

	return string(time_string) + "." + milli_string + "]";
}

long GetCurrentMillisecond()
{
	auto now = system_clock::now();
    
	auto milli = chrono::duration_cast<chrono::milliseconds>(now - chrono::time_point_cast<chrono::seconds>(now));
	return milli.count();
}

string GetRandomID()
{
	char letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
	string res;
    for (int i=0;i<8;++i)
		res.push_back(letters[distribution(generator)]);
	return res;
}

#endif
