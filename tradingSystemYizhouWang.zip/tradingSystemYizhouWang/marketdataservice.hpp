/**
 * marketdataservice.hpp
 * Defines the data types and Service for order book market data.
 *
 * @author Breman Thuraisingham
 */
#ifndef MARKET_DATA_SERVICE_HPP
#define MARKET_DATA_SERVICE_HPP

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include "soa.hpp"
#include "utility.hpp"

using namespace std;

// Side for market data
enum PricingSide { BID, OFFER };

/**
 * A market data order with price, quantity, and side.
 */
class Order
{

public:

  // ctor for an order
    Order() = default;
    Order(double _price, long _quantity, PricingSide _side);

  // Get the price on the order
    double GetPrice() const;

  // Get the quantity on the order
    long GetQuantity() const;

  // Get the side on the order
    PricingSide GetSide() const;

private:
  double price;
  long quantity;
  PricingSide side;

};

/**
 * Class representing a bid and offer order
 */
class BidOffer
{

public:

  // ctor for bid/offer
  BidOffer(const Order &_bidOrder, const Order &_offerOrder);

  // Get the bid order
  const Order& GetBidOrder() const;

  // Get the offer order
  const Order& GetOfferOrder() const;

private:
  Order bidOrder;
  Order offerOrder;

};

/**
 * Order book with a bid and offer stack.
 * Type T is the product type.
 */
template<typename T>
class OrderBook
{

public:
    
    OrderBook();

  // ctor for the order book
  OrderBook(const T &_product, const vector<Order> &_bidStack, const vector<Order> &_offerStack);

  // Get the product
  const T& GetProduct() const;

  // Get the bid stack
  const vector<Order>& GetBidStack() const;

  // Get the offer stack
  const vector<Order>& GetOfferStack() const;
    
    // get the best
    const BidOffer GetBest() const;

private:
  T product;
  vector<Order> bidStack;
  vector<Order> offerStack;

};

template<typename T>
class MarketDataConnector;

/**
 * Market Data Service which distributes market data
 * Keyed on product identifier.
 * Type T is the product type.
 */
template<typename T>
class MarketDataService : public Service<string,OrderBook <T> >
{

private:
    
    map<string, OrderBook<T>> order_books;
    vector<ServiceListener<OrderBook<T>>*> listeners;
    MarketDataConnector<T>* connector;
    int depth;

public:

    MarketDataService();

    OrderBook<T>& GetData(string key);

    void OnMessage(OrderBook<T>& data);

    void AddListener(ServiceListener<OrderBook<T>>* listener);

    const vector<ServiceListener<OrderBook<T>>*>& GetListeners() const;

    MarketDataConnector<T>* GetConnector();

    int GetBookDepth() const;

    // Get the best bid/offer order
    virtual const BidOffer GetBestBidOffer(const string& productId);

    // Aggregate the order book
     virtual const OrderBook<T> AggregateDepth(const string& productId);
    
};

Order::Order(double _price, long _quantity, PricingSide _side)
{
  price = _price;
  quantity = _quantity;
  side = _side;
}

double Order::GetPrice() const
{
  return price;
}
 
long Order::GetQuantity() const
{
  return quantity;
}
 
PricingSide Order::GetSide() const
{
  return side;
}

BidOffer::BidOffer(const Order &_bidOrder, const Order &_offerOrder) :
  bidOrder(_bidOrder), offerOrder(_offerOrder)
{
}

const Order& BidOffer::GetBidOrder() const
{
  return bidOrder;
}

const Order& BidOffer::GetOfferOrder() const
{
  return offerOrder;
}

template<typename T>
OrderBook<T>::OrderBook(){}

template<typename T>
OrderBook<T>::OrderBook(const T &_product, const vector<Order> &_bidStack, const vector<Order> &_offerStack) :
  product(_product), bidStack(_bidStack), offerStack(_offerStack)
{
}

template<typename T>
const T& OrderBook<T>::GetProduct() const
{
  return product;
}

template<typename T>
const vector<Order>& OrderBook<T>::GetBidStack() const
{
  return bidStack;
}

template<typename T>
const vector<Order>& OrderBook<T>::GetOfferStack() const
{
  return offerStack;
}

template<typename T>
const BidOffer OrderBook<T>::GetBest() const
{
    double best_bid = INT_MIN;
    Order best_bid_order;
    for (auto& b : bidStack)
    {
        if (b.GetPrice() > best_bid)
        {
            best_bid = b.GetPrice();
            best_bid_order = b;
        }
    }

    double best_offer = INT_MAX;
    Order best_offer_order;
    for (auto& o : offerStack)
    {
        if (o.GetPrice() < best_offer)
        {
            best_offer = o.GetPrice();
            best_offer_order = o;
        }
    }

    return BidOffer(best_bid_order, best_offer_order);
}

template<typename T>
MarketDataService<T>::MarketDataService() : depth(5), connector(new MarketDataConnector<T>(this)), listeners(), order_books()
{
}

template<typename T>
OrderBook<T>& MarketDataService<T>::GetData(string key)
{
    return order_books[key];
}

template<typename T>
void MarketDataService<T>::OnMessage(OrderBook<T>& data)
{
    order_books[data.GetProduct().GetProductId()] = data;

    for (auto& l : listeners) l->ProcessAdd(data);
}

template<typename T>
void MarketDataService<T>::AddListener(ServiceListener<OrderBook<T>>* listener)
{
    listeners.push_back(listener);
}

template<typename T>
const vector<ServiceListener<OrderBook<T>>*>& MarketDataService<T>::GetListeners() const
{
    return listeners;
}

template<typename T>
MarketDataConnector<T>* MarketDataService<T>::GetConnector()
{
    return connector;
}

template<typename T>
int MarketDataService<T>::GetBookDepth() const
{
    return depth;
}

template<typename T>
const BidOffer MarketDataService<T>::GetBestBidOffer(const string& productId)
{
    return order_books[productId].GetBest();
}

template<typename T>
const OrderBook<T> MarketDataService<T>::AggregateDepth(const string& product_id)
{
    const T& prod = order_books[product_id].GetProduct();

    const vector<Order>& old_bid_stack = order_books[product_id].GetBidStack();
    unordered_map<double, long> bid_table;
    for (auto& b : old_bid_stack) bid_table[b.GetPrice()] += b.GetQuantity();
    
    vector<Order> new_bid_stack;
    for (auto& p : bid_table) new_bid_stack.emplace_back(p.first, p.second, BID);

    const vector<Order>& old_offer_stack = order_books[product_id].GetOfferStack();
    unordered_map<double, long> offer_table;
    for (auto& b : old_offer_stack) bid_table[b.GetPrice()] += b.GetQuantity();
    
    vector<Order> new_offer_stack;
    for (auto& p : offer_table) new_offer_stack.emplace_back(p.first, p.second, OFFER);

    return OrderBook<T>(prod, new_bid_stack, new_offer_stack);
}

template<typename T>
class MarketDataConnector : public Connector<OrderBook<T>>
{
public:

    MarketDataConnector(MarketDataService<T>* service);

    void Publish(OrderBook<T>& data);

    void Subscribe(ifstream& data);

private:

    MarketDataService<T>* service;
};

template<typename T>
MarketDataConnector<T>::MarketDataConnector(MarketDataService<T>* service): service(service)
{
}

template<typename T>
void MarketDataConnector<T>::Publish(OrderBook<T>& data) {}

template<typename T>
void MarketDataConnector<T>::Subscribe(ifstream& data)
{
    int _thread = service->GetBookDepth() * 2;
    long _count = 0;
    vector<Order> _bidStack;
    vector<Order> _offerStack;
    string _line;
    while (getline(data, _line))
    {
        string _productId;

        stringstream _lineStream(_line);
        string _cell;
        vector<string> _cells;
        while (getline(_lineStream, _cell, ','))
        {
            _cells.push_back(_cell);
        }
        
        _productId = _cells[0];
        double _price = StringPriceToNum(_cells[1]);
        long _quantity = stol(_cells[2]);
        PricingSide _side;
        if (_cells[3] == "BID") _side = BID;
        else if (_cells[3] == "OFFER") _side = OFFER;
        Order _order(_price, _quantity, _side);
        switch (_side)
            {
            case BID:
                _bidStack.push_back(_order);
                break;
            case OFFER:
                _offerStack.push_back(_order);
                break;
            }
        
        _count++;
        if (_count % _thread == 0)
        {
            T _product = GetTreasuryFromCUSIP(_productId);
            OrderBook<T> _orderBook(_product, _bidStack, _offerStack);
            service->OnMessage(_orderBook);

            _bidStack = vector<Order>();
            _offerStack = vector<Order>();
        }
    }
}


#endif
